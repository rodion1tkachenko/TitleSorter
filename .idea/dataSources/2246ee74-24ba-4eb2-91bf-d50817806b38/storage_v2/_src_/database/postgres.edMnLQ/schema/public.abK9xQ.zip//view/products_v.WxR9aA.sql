create view products_v(name, type_name, price) as
SELECT p.name,
       pt.type_name,
       p.price
FROM products p
         JOIN product_types pt ON p.type_id = pt.id;

alter table products_v
    owner to postgres;

