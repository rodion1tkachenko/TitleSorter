create view heroes_v(hair, eye) as
SELECT superheroes.hair,
       superheroes.eye
FROM superheroes;

alter table heroes_v
    owner to postgres;

